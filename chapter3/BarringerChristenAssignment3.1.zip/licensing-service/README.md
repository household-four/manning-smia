# Assignment 3.1
Christen Barringer

# How to Run
```
mvn spring-boot-run 
```

Send HTTP requests to `http://localhost:8080/v1/organization/optimaGrowth/license`

Use `requests.json` for example requests.