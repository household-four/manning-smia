package com.optimagrowth.license;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LicenseServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
