package com.optimagrowth.license.model;

public enum Category {
    SPORTS,
    FITNESS,
    ARTS,
    LITERATURE
}
